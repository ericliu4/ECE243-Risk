ECE243 Final Project - Risk Global Domination: single player
