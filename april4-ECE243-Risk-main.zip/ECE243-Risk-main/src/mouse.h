#ifndef MOUSE_H
#define MOUSE_H

#include "globals.h"
#include "structs.h"

int checkIfMousePluggedIn();


mouse_movement get_mouse_movement();

#endif /*MOUSE_H*/